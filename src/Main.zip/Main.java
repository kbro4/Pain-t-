package com.example.paint;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;
import java.util.Timer;

/**
 * Starts program, creates borderpane, lays items on borderpane, operates aware save
 * @author Kurt Brown
 * @version 2.1.1
 */
public class Main extends Application {

    private static BorderPane pane;
    private static Stage stage2;
    private Boolean updated;

    /**
     * Starts the program, creates borderpane, and lays items on it
     * @param stage The stage of the interface
     * @throws IOException if stage fails
     */
    @Override
    public void start(Stage stage) throws IOException {
        // Launches starting interface
        ImageView imgView = user_interface(stage);
        stage2 = stage;
        pane = new BorderPane();

        // Creates border pane, menu bar, help bar, and draw bar
        display_menu menu = new display_menu();
        help_bar help = new help_bar();
        ScrollPane scroll = new ScrollPane();
        scroll.setContent(menu.get_canvas());
        scroll.setPannable(true);
        draw pen1 = new draw(menu.get_canvas());
        timer new_timer = new timer();

        // Puts everything together on the border pane
        pane.setTop(pen1.get_HBox());
        pane.setCenter(scroll);

        // Sets scene
        stage.setTitle("Paint");
        Scene scene = new Scene(pane, 595, 355, Color.WHITE);
        stage.setScene(scene);
        stage.show();

        // Sets default pen tool
        pane.setCenter(pen1.draw_tool(menu.get_canvas()));

        // Processes exit request
        stage.setOnCloseRequest(e -> {
            updated = pen1.check_updated();
            e.consume();
            aware_save(pen1, new_timer.get_timer());
        });

    }

    /**
     * Checks for unsaved changes, if so, alerts user and asks if they want to save them
     * @param pen1 The free draw object
     * @param timer The timer object
     */
    public void aware_save(draw pen1, Timer timer){
        // Checks to see if the canvas has been updated
        if (updated) {
            // Creates alert box
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Unsaved changes");
            alert.setContentText("Would you like to save your changes?");

            // Creates save, discard, cancel options
            ButtonType save_opt = new ButtonType("Save");
            ButtonType discard_opt = new ButtonType("Don't Save");
            ButtonType cancel_opt = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
            alert.getButtonTypes().setAll(save_opt, discard_opt, cancel_opt);

            Optional<ButtonType> result = alert.showAndWait();
            if (result.get() == save_opt) {
                // User chose save
                // Checks for save versus save as
                if (pen1.get_file() != null){
                    pen1.save(stage2, pen1.get_file(), pen1.get_imageview(), pen1.get_canvas());
                }
                else {
                    pen1.save_as(stage2, pen1.get_file(), pen1.get_imageview(), pen1.get_canvas());
                }
                timer.cancel();
                stage2.close();

            } else if (result.get() == discard_opt) {
                // User chose don't save
                timer.cancel();
                stage2.close();
            } else {
                // User chose cancel or exited the alert
                alert.close();
            }
        }
        else {
            timer.cancel();
            stage2.close();
        }
    }

    /**
     * Sets borderpane
     * @param new_pane The new pane to make the main borderpane
     */
    public static void set_pane(BorderPane new_pane){
        pane = new_pane;
    }

    /**
     * Gets the borderpane
     * @return pane The current borderpane
     */
    public static BorderPane get_pane(){
        return pane;
    }

    /**
     * Gets the current stage
     * @return stage2 The current stage
     */
    public static Stage get_stage(){
        return stage2;
    }

    /**
     * Main method, launches program
     * @param args
     */
    public static void main(String[] args) {
        launch();
    }

    /**
     * Checks whether the canvas has been changed since last save
     * @return updated Whether the canvas has been changed
     */
    public Boolean get_updated(){
        return updated;
    }

    /**
     * Sets the updated value when the canvas is changed
     * @param new_value True or false, depending on if the canvas has been updated
     */
    public void set_updated(Boolean new_value){
        updated = new_value;
    }

    /**
     * Creates the beginning user interface
     * @param stage The current stage
     * @return imgView The created imageview
     */
    public static ImageView user_interface(Stage stage){
        // Opening user interface
        ImageView imgView = new ImageView();
        imgView.setFitWidth(20);
        imgView.setFitHeight(20);

        return imgView;
    }

}