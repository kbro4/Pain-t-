package com.example.paint;

import javafx.animation.Timeline;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.RenderedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Optional;
import java.util.Timer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Creates and displays menu bar, canvas, and tabs
 * @author Kurt Brown
 * @version 2.1.1
 */
public class display_menu {
    protected MenuBar menubar;
    public static Canvas canvas1;
    private Menu file;
    private MenuItem op_item;
    private MenuItem s_item;
    private MenuItem sa_item;
    private MenuItem close_item;
    private VBox vbox;
    private static ImageView imageview;
    private File file2;
    public static ScrollPane scroll;
    public File file1;
    public Boolean saved;
    public Boolean image_loaded;
    private int tabcounter = 0;
    private TabPane tabpane;
    private Tab tab1;
    private Tab current_tab;
    private HashMap tab_files;
    public Image first_image;

    /**
     * Default constructor, creates menu bar, canvas, and key combination
     */
    public display_menu(){

        ScrollPane scroll = new ScrollPane();
        scroll.setPannable(true);
        image_loaded = false;
        tab_files = new HashMap<Tab, File>();

        // Creates Menu bar
        menubar = new MenuBar();

        // Creates File bar
        file = new Menu("File");
        op_item = new MenuItem("Open");
        s_item = new MenuItem("Save");
        sa_item = new MenuItem("Save as");
        close_item = new MenuItem("Close");
        file.getItems().addAll(op_item, s_item, sa_item, close_item);
        menubar.getMenus().add(file);
        vbox = new VBox(menubar);
        imageview = new ImageView();

        // Creates canvas
        canvas1 = new Canvas(1100.0, 700.0);
        GraphicsContext gc = canvas1.getGraphicsContext2D();
        gc.setFill(Color.WHITE);
        gc.fillRect(0, 0, gc.getCanvas().getWidth(), gc.getCanvas().getHeight());
        scroll.setContent(canvas1);
        Main.get_pane().setCenter(scroll);

        //File bar options
        // Opens image
        op_item.setOnAction(o->{
            // Checks to see if there is already an image loaded
            if (image_loaded == true){
                tab_open(canvas1);
            }
            else {
                open_image();
            }
        });
        // Save
        s_item.setOnAction(p->{
            save(Main.get_stage(), file2, imageview, canvas1);
            saved = true;
        });
        //Save as
        sa_item.setOnAction(l->{
            save_as(Main.get_stage(), file2, imageview, canvas1);
            saved = true;
        });

        // Close
        close_item.setOnAction(r->{
            close(Main.get_stage());
        });

        op_item.setAccelerator(new KeyCodeCombination(KeyCode.O, KeyCombination.CONTROL_DOWN));
        s_item.setAccelerator(new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN));
        close_item.setAccelerator(new KeyCodeCombination(KeyCode.E, KeyCombination.CONTROL_DOWN));
    }

    /**
     * Sets image to specified image value
     * @param image
     */
    public void set_image(Image image){
        first_image = image;
    }

    /**
     * Gets the original image
     * @return first_image The starting image of the user interface
     */
    public Image get_image(){
        return first_image;
    }

    /**
     * Gets file menu
     * @return vbox The VBox that houses the file menu
     */
    public VBox get_vbox(){
        return this.vbox;
    }

    /**
     * Gets the current imageview
     * @return imageView The current imageview
     */
    public ImageView get_imageview(){
        return this.imageview;
    }

    /**
     * Gets the current canvas
     * @return canvas1 The current working canvas
     */
    public Canvas get_canvas(){
        return this.canvas1;
    }

    /**
     * Gets the canvas passed to the method
     * @param canvas2 A canvas passed to the method
     * @return canvas2 The canvas passed to the method
     */
    public Canvas get_canvas(Canvas canvas2){
        return canvas2;
    }

    /**
     * Sets the canvas width to a new width
     * @param new_width The new desired width of the canvas
     */
    public void alter_canvas_width(double new_width){
        canvas1.setWidth(new_width);
    }

    /**
     * Sets the canvas height to a new height
     * @param new_height The new desired height of the canvas
     */
    public void alter_canvas_height(double new_height){
        canvas1.setHeight(new_height);
    }

    /**
     * Opens an image
     */
    public void open_image() {
        // Creates file chooser
        Stage stage = new Stage();
        stage.setTitle("Open");
        final FileChooser fileChooser = new FileChooser();
        file1 = fileChooser.showOpenDialog(stage);

        // Loads image
        Image image = new Image(file1.toURI().toString());
        imageview = new ImageView(image);

        // Sets image
        set_image(image);

        // Sets canvas w/image
        canvas1.setHeight(image.getHeight());
        canvas1.setWidth(image.getWidth());
        setCanvas(canvas1, image);

        // Sets scrollpane
        scroll = new ScrollPane();
        scroll.setContent(canvas1);
        Main.get_pane().setCenter(scroll);

        // Sets the file
        set_file(file1);

        // Sets that there has been an image loaded
        image_loaded = true;
    }

    /**
     * Opens an image with tabs
     * @param canvas The current canvas
     */
    public void tab_open(Canvas canvas){
        if (tabcounter == 0){
            // Creates first tab
            tabpane = new TabPane();
            tab1 = new Tab();
            tab1.setText("Tab 1");
            scroll.setContent(canvas);
            tab1.setContent(scroll);
            tabpane.getTabs().add(tab1);
            tabcounter = tabcounter + 2;

            // Sets the file
            set_file(file1);

            // Saves the tab, file combination
            tab_files.put(tab1, file1);

            // Creates new borderpane for tabpane
            BorderPane innerpane = new BorderPane();
            innerpane.setTop(tabpane);
        }

        // Creates new tab
        Tab new_tab = new Tab();
        new_tab.setText("Tab " + tabcounter);

        // Creates new canvas
        Canvas new_canvas = new Canvas();

        // Creates file chooser
        Stage stage = new Stage();
        stage.setTitle("Open");
        final FileChooser fileChooser = new FileChooser();
        File new_file;
        new_file = fileChooser.showOpenDialog(stage);

        // Loads image
        Image image = new Image(new_file.toURI().toString());
        imageview = new ImageView(image);

        // Sets canvas w/image
        new_canvas.setHeight(image.getHeight());
        new_canvas.setWidth(image.getWidth());
        setCanvas(new_canvas, image);

        // Sets scrollpane
        scroll = new ScrollPane();
        scroll.setContent(get_canvas(new_canvas));

        // Puts new canvas in new tab
        new_tab.setContent(scroll);

        // Increments tab counter
        tabcounter = tabcounter + 1;

        // Sets the file
        set_file(new_file);
        tab_files.put(new_tab, new_file);

        // Sets the image
        set_image(image);

        // Adds new tab to tabpane
        get_tabpane().getTabs().addAll(new_tab);

        // Creates new borderpane to put in the main one
        BorderPane innerpane = new BorderPane();
        innerpane.setTop(tabpane);

        // Puts new Borderpane in old one
        Main.get_pane().setCenter(innerpane);
    }

    /**
     * Sets a new canvas as the current working canvas
     * @param canvas The new canvas one wants to set the working canvas to
     */
    public void set_canvas(Canvas canvas){
        canvas1 = canvas;
    }

    /**
     * Gets the currently selected tab
     * @return current_tab The currently selected tab
     */
    public Tab get_current_tab(){
        current_tab = tabpane.getSelectionModel().getSelectedItem();
        return current_tab;
    }

    /**
     * Gets the file for the current tab
     * @return get_file() The current file
     */
    public File get_tab_file(){
        current_tab = tabpane.getSelectionModel().getSelectedItem();
        set_file(file1);
        return get_file();
    }

    /**
     * Gets the tabpane
     * @return tabpane The tabpane
     */
    public TabPane get_tabpane(){
        return tabpane;
    }

    /**
     * Sets a new tabpane as the working tabpane
     * @param new_tabpane The new desired tabpane
     */
    public void set_tabpane(TabPane new_tabpane){
        tabpane = new_tabpane;
    }

    /**
     * Gets the scrollpane
     * @return scroll The scrollpane
     */
    public ScrollPane get_scrolls(){
        return this.scroll;
    }

    /**
     * Sets a new canvas as the working one with an image underneath it
     * @param canvas1 The canvas one wants to set the working canvas to
     * @param img The imaage one wants to place underneath the new working canvas
     */
    public static void setCanvas(Canvas canvas1, Image img){
        // Sets image on canvas
        GraphicsContext gc = canvas1.getGraphicsContext2D();
        gc.drawImage(img, 0, 0,canvas1.getWidth(), canvas1.getHeight());
    }

    /**
     * Saves the current file
     * @param stage The current stage
     * @param file The file to be saved
     * @param imgView The current imageview
     * @param canvas The current, working canvas
     */
    public void save(Stage stage, File file, ImageView imgView, Canvas canvas) {
        if (tabcounter != 0){
            get_current_tab();
        }
        SnapshotParameters snap = new SnapshotParameters();
        file = get_file();
        if (file != null){
            try {
                // Saves image
                WritableImage image = canvas.snapshot(snap, null);
                RenderedImage renderedImage = SwingFXUtils.fromFXImage(image, null);
                ImageIO.write(renderedImage, "png", file);
            }
            catch (IOException exception){
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE,null, exception);
            }
        }
    }

    /**
     * Saves the current file with a specified location and url
     * @param stage The current stage
     * @param file The current file
     * @param imgView The current imageview
     * @param canvas The current, working canvas
     */
    public void save_as(Stage stage, File file, ImageView imgView, Canvas canvas) {
        String orig_ext = new String(check_extension());
        Boolean continued = true;
        // Creates file chooser
        FileChooser filechooser = new FileChooser();
        FileChooser.ExtensionFilter extFilter1 = new FileChooser.ExtensionFilter(
                "image files (*.png)", "*.png");
        FileChooser.ExtensionFilter extFilter2 = new FileChooser.ExtensionFilter(
                "image files (*.jpg)", "*.jpg");
        FileChooser.ExtensionFilter extFilter3 = new FileChooser.ExtensionFilter(
                "image files (*.bmp)", "*.bmp");
        filechooser.getExtensionFilters().addAll(extFilter1, extFilter2, extFilter3);
        filechooser.setSelectedExtensionFilter(extFilter1);
        file = filechooser.showSaveDialog(stage);
        if (!check_same_type(file, orig_ext)){
            if (!loss_alert()){
                SnapshotParameters snap = new SnapshotParameters();
                if (file != null){
                    try {
                        // Saves image
                        WritableImage image = canvas.snapshot(snap, null);
                        RenderedImage renderedImage = SwingFXUtils.fromFXImage(image, null);
                        ImageIO.write(renderedImage, "png", file);
                    }
                    catch (IOException exception){
                        Logger.getLogger(Main.class.getName()).log(Level.SEVERE,null, exception);
                    }
                }

                set_file(file);
            }
        }
    }

    /**
     * Checks to see if the user wants to save to a different file type
     * @return Boolean whether the user wants to cancel the save
     */
    public Boolean loss_alert(){
        // Creates alert box
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Change file format");
        alert.setContentText("Changing the file format may result in data loss. Continue?");

        // Creates save, discard, cancel options
        ButtonType yes_opt = new ButtonType("Yes");
        ButtonType cancel_opt = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().setAll(yes_opt, cancel_opt);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == cancel_opt) {
            alert.close();
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Gets the file extension
     * @return suffix The last three characters of the url
     */
    public String check_extension(){
        String suffix = file.toString().substring(file.toString().length() - 3);
        return suffix;
    }

    /**
     * Checks to see whether the file is the same type as the desired save file format
     * @param file The file to be saved
     * @param string The original extension of the file
     * @return boolean Whether the file format has been changed or not
     */
    public Boolean check_same_type(File file, String string){
        String suffix = file.toString().substring(file.toString().length() - 3);
        if (suffix == string){
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Sets a new file as the current, working file
     * @param new_file The new file to set as the current, working file
     */
    public void set_file(File new_file){
        file1 = new_file;
    }

    /**
     * Gets the current, working file
     * @return file1 The current, working file
     */
    public File get_file(){
        return file1;
    }

    /**
     * Closes the application
     * @param stage2 The current stage
     */
    public static void close(Stage stage2){
        // Close function
        stage2.close();
    }

}
